# `@jibe/embed` — Jibe Embeddable Workspace (`embed.jibe.run`)

The Jibe-branded embeddable workspace for dev docs and playgrounds: a shared
`https://embed.jibe.run` origin serving one Service Worker, one `CacheStorage`,
and one lazy WASM instance, with per-embed workspace isolation via
`?id=<workspaceId>` OPFS subdirectories (`projectRoot(workspaceId)`).

## Embedding a Workspace

```ts
import { createJibeEmbed } from "@jibe/embed";

const workspace = await createJibeEmbed(document.getElementById("slot"), {
  template: "react",
  chrome: "studio",
  files: {
    "src/Board.jsx": { code: boardSource, active: true },
    "src/data.js": { code: seed, hidden: true, readOnly: true },
  },
  onReady: (handle) => track(handle.workspaceId),
  onError: (failure) => report(failure.kind, failure.message),
  onFork: (snapshot) => save(snapshot.files, snapshot.lock),
});
await workspace.client.writeFile({
  path: "src/main.jsx",
  text: nextEntry,
});
const snapshot = await workspace.client.exportSnapshot({});
```

`chrome` decides how much frame to draw: `studio` (editor, tabs, navigator,
console), `preview` (running app plus the console drawer), `minimal` (the app
and the Fork watermark), or `none` (the app, edge to edge). Fork is drawn only
when it has somewhere to go — `onFork`, or `fork: { href }`; `fork: false`
removes it.

### Bindings

The core entry stays framework-free. Bindings mount the same workspace from a
component and re-mount only when the seed changes:

```tsx
// @jibe/embed/react — also /solid and /vue
import { JibeEmbed } from "@jibe/embed/react";

<JibeEmbed
  template="react"
  height={420}
  onFork={(snapshot) => save(snapshot.files)}
/>;
```

```svelte
<!-- @jibe/embed/svelte -->
<div use:jibeEmbed={{ template: "svelte", chrome: "studio" }} />
```

Source kinds: `files` (inline), `snapshot` (hosted snapshot/jibe ID URL),
`tarball` (`.tar.gz` URL), and `github` (`{ repo, ref, subpath }` via
`codeload.github.com`). All nine procedures (`init`, `readFile`, `writeFile`,
`addFile`, `apply`, `deleteFile`, `listFiles`, `getStatus`, `exportSnapshot`) ride a typed
`MessagePort` link (`@orpc/client/message-port` ↔ `@orpc/server/message-port`).
`apply({ write, remove })` lands a batch of changes as one rebuild; `getStatus` reports the
phases of the last rebuild (`timings`), so a consumer can see where a rebuild spends its time.

## Isolation Model

- Each embed carries `?id=<workspaceId>`; the SW resolves every `/`,
  `/dist/*`, and file read to that workspace's OPFS subdirectory and tags
  `vent-hmr-update` broadcasts with the same id so siblings never cross-mount.
- `embed.jibe.run` serves `Cross-Origin-Resource-Policy: cross-origin` so any
  docs page can frame it; `Cross-Origin-Embedder-Policy: require-corp`
  keeps `crossOriginIsolated` inside the iframe. Safari never implemented
  `credentialless`, so that is the only portable host contract.
- The host UI (`/embed/embed.js`) lazily loads `@jibe/vent/page-client` and
  CodeMirror 6, keeping the initial entry chunk lightweight with zero static
  edges to Rolldown, Babel, JSPM, or Solid.
