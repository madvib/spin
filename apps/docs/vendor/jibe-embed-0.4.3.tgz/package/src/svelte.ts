// packages/embed/src/svelte.ts — the Svelte binding.
//
// Svelte's action contract (`use:jibeEmbed={options}`) needs no compiler
// integration and works in Svelte 4 and 5. The action returns `destroy` and
// `update`, so a state change to the options remounts the workspace.
import {
  createJibeEmbed,
  type JibeEmbedHandle,
  type JibeEmbedOptions,
} from "./sdk.ts";

export interface JibeEmbedAction {
  /** Replace the mount options; remounts with the new seed. */
  update(options: JibeEmbedOptions): void;
  /** Tear the workspace down. */
  destroy(): void;
}

function seedSignature(options: JibeEmbedOptions): string {
  return JSON.stringify({
    embedOrigin: options.embedOrigin,
    workspaceId: options.workspaceId,
    bundler: options.bundler,
    from: options.from,
    template: options.template,
    files: options.files,
    externalResources: options.externalResources,
    storage: options.storage,
  });
}

function liveSignature(options: JibeEmbedOptions): string {
  return JSON.stringify({
    view: options.view,
    chrome: options.chrome,
    activeFile: options.activeFile,
    readOnly: options.readOnly,
    theme: options.theme,
  });
}

/**
 * Mount a Jibe workspace on any element:
 *
 * ```svelte
 * <div use:jibeEmbed={{ template: "svelte", chrome: "studio", height: 420 }} />
 * ```
 */
export function jibeEmbed(
  node: HTMLElement,
  initial: JibeEmbedOptions,
): JibeEmbedAction {
  let generation = 0;
  let handle: JibeEmbedHandle | null = null;
  let lastSeed = seedSignature(initial);
  let lastLive = liveSignature(initial);

  const mount = (options: JibeEmbedOptions): void => {
    generation += 1;
    const mine = generation;
    handle?.destroy();
    handle = null;
    void createJibeEmbed(node, options).then(
      (mounted) => {
        if (mine !== generation) {
          mounted.destroy();
          return;
        }
        handle = mounted;
      },
      () => {
        /* `onError` on the options already reported it */
      },
    );
  };

  mount(initial);

  return {
    update: (options: JibeEmbedOptions): void => {
      const seed = seedSignature(options);
      if (seed !== lastSeed) {
        lastSeed = seed;
        lastLive = liveSignature(options);
        mount(options);
        return;
      }
      const live = liveSignature(options);
      if (live !== lastLive) {
        lastLive = live;
        if (handle !== null) {
          void handle.configure({
            view: options.view,
            chrome: options.chrome,
            activeFile: options.activeFile,
            readOnly: options.readOnly,
            theme: options.theme,
          });
        }
      }
    },
    destroy: (): void => {
      generation += 1;
      handle?.destroy();
      handle = null;
    },
  };
}
