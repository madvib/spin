// packages/embed/src/sdk_slot.ts — the embed frame slot lifecycle.
//
// One frame slot per handle: `mounting` before the first mount settles, then
// live or destroyed. Every transition runs inside `serialize`, so a running
// task owns the slot and queued transitions observe its settled state.
import { mountEmbedFrame, type EmbedContractClient } from "./sdk_mount.ts";
import type { SlotMount } from "./sdk_types.ts";
import type { EmbedSnapshot } from "./sdk_types.ts";
import type { JibeEmbedOptions } from "./sdk.ts";

export type EmbedSlot =
  | { readonly status: "mounting" }
  | { readonly status: "live"; readonly mount: SlotMount }
  | { readonly status: "destroyed" };

// Typed RPC forwarding: one generic over the contract client's methods.
export type ClientMethod = keyof EmbedContractClient;
export type ClientArgs<K extends ClientMethod> = Parameters<
  EmbedContractClient[K]
>;

export interface SlotDriver {
  readonly mountFirst: () => Promise<SlotMount>;
  readonly withLive: <T>(call: (mount: SlotMount) => Promise<T>) => Promise<T>;
  readonly readIframe: () => HTMLIFrameElement;
  readonly exportSnapshot: () => Promise<EmbedSnapshot>;
  readonly destroy: () => void;
}

export interface SlotDriverDeps {
  readonly container: HTMLElement;
  readonly options: JibeEmbedOptions;
  readonly seed: Parameters<typeof mountEmbedFrame>[0]["seed"];
  readonly workspaceId: string;
}

// Build the slot driver: `slot` stays in the closure; the returned handle
// functions read it only inside `serialize`.
export function createSlotDriver(deps: SlotDriverDeps): {
  readonly driver: SlotDriver;
} {
  const { container, options, seed, workspaceId } = deps;
  let slot: EmbedSlot = { status: "mounting" };
  let chain: Promise<void> = Promise.resolve();

  // Every slot transition runs inside `serialize`: each task observes the
  // settled state of its predecessor.
  const serialize = <T>(task: () => Promise<T>): Promise<T> => {
    const run: Promise<T> = chain.then(task);
    chain = run.then(
      () => undefined,
      () => undefined,
    );
    return run;
  };
  const destroyMount = (mount: SlotMount): void => {
    window.removeEventListener("message", mount.listener);
    mount.channel.port1.close();
    mount.iframe.remove();
  };
  const mountEmbed = (snapshot: EmbedSnapshot | null): Promise<SlotMount> =>
    mountEmbedFrame({
      seed,
      options,
      container,
      workspaceId,
      snapshotSeed: snapshot,
    });
  // Live read inside `serialize` only: resolves the live mount, throws when
  // mounting or destroyed.
  const liveLocked = async (): Promise<SlotMount> => {
    if (slot.status === "live") return slot.mount;
    throw new Error(
      slot.status === "destroyed"
        ? "jibe-embed is destroyed"
        : "jibe-embed is mounting",
    );
  };
  const withLive = <T>(call: (mount: SlotMount) => Promise<T>): Promise<T> =>
    serialize(async (): Promise<T> => call(await liveLocked()));
  // The first mount: fresh seed, then the slot goes live.
  const mountFirst = async (): Promise<SlotMount> => {
    const mount = await mountEmbed(null);
    slot = { status: "live", mount };
    return mount;
  };
  const readIframe = (): HTMLIFrameElement => {
    if (slot.status !== "live") {
      throw new Error(
        slot.status === "destroyed"
          ? "jibe-embed is destroyed"
          : "jibe-embed is mounting",
      );
    }
    return slot.mount.iframe;
  };
  const exportSnapshot = (): Promise<EmbedSnapshot> =>
    serialize(async () => (await liveLocked()).client.exportSnapshot({}));

  return {
    driver: {
      mountFirst,
      withLive,
      readIframe,
      exportSnapshot,
      destroy: (): void => {
        if (slot.status === "live") destroyMount(slot.mount);
        slot = { status: "destroyed" };
      },
    },
  };
}
