// packages/embed/src/sdk.ts — the consumer SDK for Jibe embeds.
//
// `createJibeEmbed` mounts an `<iframe>` at `${embedOrigin}/embed?id=...`, waits
// for the host's `jibe-embed-ready`, transfers a `MessageChannel` port, and
// calls `init` over a typed `@orpc/client/message-port` link. No bundler, no
// OPFS, no Vent runtime imports beyond types: the parent page stays light.
//
// Split modules: `sdk_types.ts` (surface types), `sdk_url.ts` (origin,
// params, `from`, overlay normalization), `sdk_mount.ts` (one frame mount),
// `sdk_slot.ts` (slot lifecycle + staged mounting).
import type { ContractRouterClient } from "@orpc/contract";
import {
  embedContract,
  type EmbedBundlerMode,
  type EmbedEngine,
  type EmbedConfigureInput,
  type EmbedResetInput,
  type EmbedTestOutcome,
  type EmbedTheme,
} from "./contract.ts";
import { createSlotDriver, type ClientArgs } from "./sdk_slot.ts";
import { resolveEmbedMountSeed } from "./sdk_url.ts";
import type {
  EmbedAssistantRequest,
  EmbedChrome,
  EmbedFileInput,
  EmbedSnapshot,
  EmbedStorage,
  EmbedView,
  JibeEmbedConsoleEntry,
  JibeEmbedDisplayOptions,
  JibeEmbedHandle,
  EmbedFailureInfo,
} from "./sdk_types.ts";

export type {
  EmbedAssistantRequest,
  EmbedChrome,
  EmbedFileInput,
  EmbedSnapshot,
  EmbedStorage,
  EmbedView,
  JibeEmbedConsoleEntry,
  JibeEmbedDisplayOptions,
  JibeEmbedHandle,
  EmbedFailureInfo,
};
export { buildEmbedUrl } from "./sdk_url.ts";
export { connectJibeEmbedPort } from "./sdk_mount.ts";
export type { ClientArgs, ClientMethod } from "./sdk_slot.ts";

export interface JibeEmbedOptions {
  readonly embedOrigin?: string;
  readonly workspaceId?: string;
  readonly bundler?: EmbedBundlerMode;
  readonly engine?: EmbedEngine;
  /**
   * Workspace storage. Defaults to `"memory"`; see `EmbedStorage`.
   */
  readonly storage?: EmbedStorage;
  readonly view?: EmbedView;
  readonly activeFile?: string;
  // Seed selection: exactly one of `template` / `from`, plus `files`
  // overlays. `from` forks on shape — a tarball URL (`.tgz`/`.tar.gz`/
  // `.zip` suffix), any other string (snapshot URL, content-sniffed at
  // fetch), or `{ repo }` (GitHub tarball). The contract wire format keeps
  // `kind` (machines); this surface drops it (humans).
  readonly from?:
    | string
    | {
        readonly repo: string;
        readonly ref?: string;
        readonly subpath?: string;
      };
  readonly template?: "vanilla" | "solid" | "react" | "vue" | "svelte";
  readonly files?: Readonly<Record<string, EmbedFileInput>>;
  readonly readOnly?: boolean;
  readonly visibleFiles?: ReadonlyArray<string>;
  readonly showTabs?: boolean;
  readonly editorHeight?: number;
  readonly recompileDelay?: number;
  readonly externalResources?: ReadonlyArray<string>;
  readonly options?: JibeEmbedDisplayOptions;
  readonly theme?: {
    readonly preset?: "dark" | "light";
    readonly bg?: string;
    readonly fg?: string;
    readonly accent?: string;
    readonly surface?: string;
    readonly muted?: string;
    readonly border?: string;
    readonly fontFamily?: string;
    readonly previewBg?: string;
    readonly fontSize?: number;
  };
  readonly onFork?: (snapshot: EmbedSnapshot) => void;
  /**
   * Where the Fork control sends the reader. `false` removes the control.
   * A `{ href }` opens that URL in a new tab; without one, no Fork control
   * renders (callback-only snapshots stay available via `handle.client` —
   * no dead buttons, no implied backend).
   */
  readonly fork?: false | { readonly href: string };
  /**
   * Frame chrome. Defaults to `"studio"`.
   */
  readonly chrome?: EmbedChrome;
  /**
   * Called once the workspace is mounted and interactive.
   */
  readonly onReady?: (handle: JibeEmbedHandle) => void;
  /**
   * Called with a classified failure — on mount failure and when the host
   * reports an error after mount.
   */
  readonly onError?: (failure: EmbedFailureInfo) => void;
  readonly onConsole?: (entry: JibeEmbedConsoleEntry) => void;
  readonly onTestComplete?: (outcome: EmbedTestOutcome) => void;
  readonly onAssistant?: (request: EmbedAssistantRequest) => void;
  /**
   * Show developer diagnostics alongside consumer failure copy. Defaults to
   * `false` (emits `debug=1`).
   */
  readonly debug?: boolean;
}
export type EmbedContractClient = ContractRouterClient<typeof embedContract>;

export async function createJibeEmbed(
  container: HTMLElement,
  options: JibeEmbedOptions,
): Promise<JibeEmbedHandle> {
  const seed = resolveEmbedMountSeed(options);
  const { driver } = createSlotDriver({
    container,
    options,
    seed,
    workspaceId: seed.workspaceId,
  });
  // The first mount: fresh seed, live slot, then the handle.
  await driver.mountFirst();
  // Typed RPC forwarding over the slot: `withLive` serializes calls onto
  // the live mount.
  const withLive = driver.withLive;
  const client: EmbedContractClient = {
    init: (...args: ClientArgs<"init">) =>
      withLive((mount) => mount.client.init(...args)),
    readFile: (...args: ClientArgs<"readFile">) =>
      withLive((mount) => mount.client.readFile(...args)),
    writeFile: (...args: ClientArgs<"writeFile">) =>
      withLive((mount) => mount.client.writeFile(...args)),
    addFile: (...args: ClientArgs<"addFile">) =>
      withLive((mount) => mount.client.addFile(...args)),
    deleteFile: (...args: ClientArgs<"deleteFile">) =>
      withLive((mount) => mount.client.deleteFile(...args)),
    apply: (...args: ClientArgs<"apply">) =>
      withLive((mount) => mount.client.apply(...args)),
    reset: (...args: ClientArgs<"reset">) =>
      withLive((mount) => mount.client.reset(...args)),
    configure: (...args: ClientArgs<"configure">) =>
      withLive((mount) => mount.client.configure(...args)),
    runTests: (...args: ClientArgs<"runTests">) =>
      withLive((mount) => mount.client.runTests(...args)),
    listFiles: (...args: ClientArgs<"listFiles">) =>
      withLive((mount) => mount.client.listFiles(...args)),
    getStatus: (...args: ClientArgs<"getStatus">) =>
      withLive((mount) => mount.client.getStatus(...args)),
    exportSnapshot: () => driver.exportSnapshot(),
  };
  const handle: JibeEmbedHandle = {
    get iframe(): HTMLIFrameElement {
      return driver.readIframe();
    },
    workspaceId: seed.workspaceId,
    client,
    reset: (input?: EmbedResetInput) => client.reset(input ?? {}),
    configure: (patch: EmbedConfigureInput) => client.configure(patch),
    setView: (next: EmbedView) => client.configure({ view: next }),
    setTheme: (theme: EmbedTheme) => client.configure({ theme }),
    setActiveFile: (path: string) => client.configure({ activeFile: path }),
    destroy: (): void => {
      driver.destroy();
    },
  };
  options.onReady?.(handle);
  return handle;
}
