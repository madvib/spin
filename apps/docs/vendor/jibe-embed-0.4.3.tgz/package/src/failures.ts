// packages/embed/src/failures.ts — consumer failure taxonomy.
//
// Pure: no imports, no I/O. Six closed kinds; `failureCopy` is the exact
// end-user copy rendered into the preview pane (never thrown, never logged
// as-is — diagnostics stay on the `debug` channel).
export type EmbedFailure =
  | "toolchain-unavailable"
  | "workspace-invalid"
  | "origin-unreachable"
  | "version-unsupported"
  | "isolation-required"
  | "boot-timeout";

export interface FailureCopy {
  readonly title: string;
  readonly body: string;
}

const TITLE = "This embed couldn't load.";

const BODIES: Record<EmbedFailure, string> = {
  "toolchain-unavailable":
    "The preview toolchain failed to load. Check your connection and retry.",
  "workspace-invalid":
    "The workspace files couldn't be read. The publisher's seed may be corrupt.",
  "origin-unreachable":
    "The embed host is unreachable. Check your connection and retry.",
  "version-unsupported":
    "This embed targets an unsupported host version. The publisher should update the snippet.",
  "boot-timeout":
    "The workspace stopped responding while it loaded. Reload the page to retry; if it keeps happening, the publisher's workspace or registry is the cause.",
  "isolation-required":
    "The page embedding it is not cross-origin isolated. The host must send Cross-Origin-Opener-Policy: same-origin and Cross-Origin-Embedder-Policy: require-corp on its own document; credentialless isolates Chromium and Firefox but not Safari.",
};

export function failureCopy(failure: EmbedFailure): FailureCopy {
  return { title: TITLE, body: BODIES[failure] };
}

/** True when an unknown value is one of the closed kinds. */
export function isEmbedFailure(value: unknown): value is EmbedFailure {
  return (
    value === "toolchain-unavailable" ||
    value === "workspace-invalid" ||
    value === "origin-unreachable" ||
    value === "version-unsupported" ||
    value === "isolation-required" ||
    value === "boot-timeout"
  );
}

/** Extracts the failure kind carried on a thrown error, if any. */
export function failureOf(error: unknown): EmbedFailure | null {
  if (typeof error !== "object" || error === null) return null;
  const carried = Reflect.get(error, "failure");
  return isEmbedFailure(carried) ? carried : null;
}

/** Attaches a failure kind to an error without changing its message. */
export function withFailure(error: Error, failure: EmbedFailure): Error {
  Reflect.set(error, "failure", failure);
  return error;
}
