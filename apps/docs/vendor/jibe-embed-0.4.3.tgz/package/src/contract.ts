// packages/embed/src/contract.ts — the Jibe embed contract.
//
// Pure valibot schemas and oRPC contract definitions for the embed MessagePort
// boundary. Zero runtime or type imports from internal workspace packages so
// external consumers importing `@jibe/embed` stay self-contained.
import { oc } from "@orpc/contract";
import * as v from "valibot";

import {
  compatibilitySchema,
  compatSeamSchema,
  diagnosticSchema,
  embedConfigureInputSchema,
  embedConfigureOutputSchema,
  embedResetInputSchema,
  embedResetOutputSchema,
  embedSourceSchema,
  embedTestCaseSchema,
  embedTestFileSchema,
  embedTestOutcomeSchema,
  embedThemeSchema,
  type EmbedBundlerMode,
  type EmbedEngine,
  type EmbedConfigureInput,
  type EmbedConfigureOutput,
  type EmbedInitState,
  type EmbedResetInput,
  type EmbedResetOutput,
  type EmbedSource,
  type EmbedTestOutcome,
  type EmbedTheme,
} from "./contract_schemas.ts";

export {
  compatibilitySchema,
  compatSeamSchema,
  diagnosticSchema,
  embedConfigureInputSchema,
  embedConfigureOutputSchema,
  embedResetInputSchema,
  embedResetOutputSchema,
  embedSourceSchema,
  embedTestCaseSchema,
  embedTestFileSchema,
  embedTestOutcomeSchema,
  embedThemeSchema,
  type EmbedBundlerMode,
  type EmbedEngine,
  type EmbedConfigureInput,
  type EmbedConfigureOutput,
  type EmbedInitState,
  type EmbedResetInput,
  type EmbedResetOutput,
  type EmbedSource,
  type EmbedTestOutcome,
  type EmbedTheme,
};

const initInput = v.strictObject({
  workspaceId: v.optional(v.string()),
  bundler: v.optional(v.picklist(["off", "lazy", "eager"])),
  engine: v.optional(v.picklist(["rolldown", "lite", "auto"])),
  activeFile: v.optional(v.string()),
  view: v.optional(v.picklist(["split", "preview", "code"])),
  template: v.optional(
    v.picklist(["vanilla", "solid", "react", "vue", "svelte"]),
  ),
  visibleFiles: v.optional(v.array(v.string())),
  hiddenFiles: v.optional(v.array(v.string())),
  readOnlyFiles: v.optional(v.array(v.string())),
  externalResources: v.optional(v.array(v.string())),
  files: v.optional(v.record(v.string(), v.string())),
  source: embedSourceSchema,
});

const initOutput = v.strictObject({
  workspaceId: v.string(),
  files: v.array(v.string()),
  activeFile: v.string(),
  bundlerLoaded: v.boolean(),
  compatibility: compatibilitySchema,
});

export const embedContract = {
  init: oc.input(initInput).output(initOutput).route({
    method: "POST",
    path: "/embed/init",
    summary:
      "Initialize an embed workspace from files, snapshot, tarball, or GitHub",
  }),
  readFile: oc
    .input(v.strictObject({ path: v.string() }))
    .output(v.strictObject({ path: v.string(), text: v.string() }))
    .route({
      method: "POST",
      path: "/embed/read-file",
      summary: "Read an embed file",
    }),
  writeFile: oc
    .input(v.strictObject({ path: v.string(), text: v.string() }))
    .output(
      v.strictObject({
        path: v.string(),
        bundlerLoaded: v.boolean(),
        diagnostics: v.array(diagnosticSchema),
      }),
    )
    .route({
      method: "POST",
      path: "/embed/write-file",
      summary: "Write an embed file",
    }),
  addFile: oc
    .input(v.strictObject({ path: v.string(), text: v.string() }))
    .output(
      v.strictObject({
        path: v.string(),
        files: v.array(v.string()),
        bundlerLoaded: v.boolean(),
        diagnostics: v.array(diagnosticSchema),
      }),
    )
    .route({
      method: "POST",
      path: "/embed/add-file",
      summary: "Add an embed file",
    }),
  deleteFile: oc
    .input(v.strictObject({ path: v.string() }))
    .output(
      v.strictObject({
        path: v.string(),
        files: v.array(v.string()),
      }),
    )
    .route({
      method: "POST",
      path: "/embed/delete-file",
      summary: "Delete an embed file",
    }),
  apply: oc
    .input(
      v.strictObject({
        write: v.optional(v.record(v.string(), v.string())),
        remove: v.optional(v.array(v.string())),
        rebuild: v.optional(v.boolean()),
      }),
    )
    .output(
      v.strictObject({
        files: v.array(v.string()),
        diagnostics: v.array(diagnosticSchema),
      }),
    )
    .route({
      method: "POST",
      path: "/embed/apply",
      summary: "Apply a batch of file changes and rebuild once",
    }),
  reset: oc.input(embedResetInputSchema).output(embedResetOutputSchema).route({
    method: "POST",
    path: "/embed/reset",
    summary:
      "Reset the workspace to its initial seed (or a new file map) and rebuild once",
  }),
  configure: oc
    .input(embedConfigureInputSchema)
    .output(embedConfigureOutputSchema)
    .route({
      method: "POST",
      path: "/embed/configure",
      summary:
        "Update live host view, chrome, activeFile, readOnly, or theme without reloading the frame",
    }),
  runTests: oc
    .input(v.strictObject({ files: v.optional(v.array(v.string())) }))
    .output(embedTestOutcomeSchema)
    .route({
      method: "POST",
      path: "/embed/run-tests",
      summary: "Run workspace tests in the browser and return the outcome",
    }),
  listFiles: oc
    .input(v.strictObject({}))
    .output(v.strictObject({ files: v.array(v.string()) }))
    .route({
      method: "POST",
      path: "/embed/list-files",
      summary: "List embed files",
    }),
  getStatus: oc
    .input(v.strictObject({}))
    .output(
      v.strictObject({
        workspaceId: v.string(),
        bundler: v.picklist(["off", "lazy", "eager"]),
        bundlerLoaded: v.boolean(),
        engine: v.picklist(["rolldown", "lite", "esm-native"]),
        compatibility: compatibilitySchema,
        /** Phases of the last completed rebuild; null before the first ends. */
        timings: v.nullable(
          v.strictObject({
            readMs: v.number(),
            resolveMs: v.number(),
            configMs: v.number(),
            bundleMs: v.number(),
            hmrMs: v.number(),
            writeMs: v.number(),
            totalMs: v.number(),
          }),
        ),
      }),
    )
    .route({ method: "POST", path: "/embed/status", summary: "Embed status" }),
  exportSnapshot: oc
    .input(v.strictObject({}))
    .output(
      v.strictObject({
        files: v.record(v.string(), v.string()),
        lock: v.nullable(v.string()),
      }),
    )
    .route({
      method: "POST",
      path: "/embed/export-snapshot",
      summary: "Export a remix snapshot of the embed workspace",
    }),
} as const;

export type EmbedContract = typeof embedContract;
