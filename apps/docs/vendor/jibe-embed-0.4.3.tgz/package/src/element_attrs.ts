// packages/embed/src/element_attrs.ts — `<jibe-embed>` attribute parsing.
//
// Value-free helpers for the custom element: one strict reader per attribute
// family plus the two option mergers (`readDisplayOptions`, `readTheme`) and
// the live-patch extractor (`readLiveConfig`). `element.ts` owns the class;
// this module owns the parsing.
import type { EmbedBundlerMode, EmbedEngine } from "./contract.ts";
import type {
  EmbedChrome,
  EmbedView,
  JibeEmbedDisplayOptions,
} from "./sdk_types.ts";
import type { JibeEmbedOptions } from "./sdk.ts";

export function readChrome(value: string | null): EmbedChrome | undefined {
  return value === "studio" ||
    value === "preview" ||
    value === "minimal" ||
    value === "none" ||
    value === "ide"
    ? value
    : undefined;
}

export function readStorage(
  value: string | null,
): "memory" | "opfs" | undefined {
  return value === "memory" || value === "opfs" ? value : undefined;
}

export function readView(value: string | null): EmbedView | undefined {
  return value === "split" || value === "preview" || value === "code"
    ? value
    : undefined;
}

export function readBundler(
  value: string | null,
): EmbedBundlerMode | undefined {
  return value === "off" || value === "lazy" || value === "eager"
    ? value
    : undefined;
}

export function readEngine(value: string | null): EmbedEngine | undefined {
  return value === "rolldown" || value === "lite" || value === "auto"
    ? value
    : undefined;
}

export function readPreset(value: string | null): "dark" | "light" | undefined {
  return value === "dark" || value === "light" ? value : undefined;
}

export function readRecompile(
  value: string | null,
): "auto" | "manual" | undefined {
  return value === "auto" || value === "manual" ? value : undefined;
}

export function readTemplate(
  value: string | null,
): "vanilla" | "solid" | "react" | "vue" | "svelte" | undefined {
  return value === "vanilla" ||
    value === "solid" ||
    value === "react" ||
    value === "vue" ||
    value === "svelte"
    ? value
    : undefined;
}

export function readBooleanAttr(
  el: Element,
  name: string,
): boolean | undefined {
  if (!el.hasAttribute(name)) return undefined;
  const raw = el.getAttribute(name)?.trim().toLowerCase();
  if (raw === "0" || raw === "false") return false;
  return true;
}

export function readNumberAttr(value: string | null): number | undefined {
  if (value === null || value.trim() === "") return undefined;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : undefined;
}

export function readCsvAttr(
  value: string | null,
): ReadonlyArray<string> | undefined {
  if (value === null) return undefined;
  const items = value
    .split(",")
    .map((item) => item.trim())
    .filter((item) => item !== "");
  return items.length > 0 ? items : undefined;
}

export function readStringAttr(el: Element, name: string): string | undefined {
  const raw = el.getAttribute(name);
  return raw !== null && raw !== "" ? raw : undefined;
}
export interface ElementPropertyState {
  readonly options: JibeEmbedDisplayOptions | undefined;
  readonly theme: JibeEmbedOptions["theme"];
  readonly files: JibeEmbedOptions["files"];
  readonly from: JibeEmbedOptions["from"];
  readonly visibleFiles: ReadonlyArray<string> | undefined;
  readonly externalResources: ReadonlyArray<string> | undefined;
}

export function readDisplayOptions(
  el: Element,
  base: JibeEmbedDisplayOptions | undefined,
): JibeEmbedDisplayOptions | undefined {
  const showNavigator = readBooleanAttr(el, "show-navigator");
  const showTabs = readBooleanAttr(el, "show-tabs");
  const showLineNumbers = readBooleanAttr(el, "show-line-numbers");
  const showConsole = readBooleanAttr(el, "show-console");
  const showTests = readBooleanAttr(el, "show-tests");
  const showAssistant = readBooleanAttr(el, "show-assistant");
  const maxConsoleMessages = readNumberAttr(
    el.getAttribute("max-console-messages"),
  );
  const showReadOnly = readBooleanAttr(el, "show-readonly");
  const closableTabs = readBooleanAttr(el, "closable-tabs");
  const wrapContent = readBooleanAttr(el, "wrap-content");
  const fontSize = readNumberAttr(el.getAttribute("font-size"));
  const autoReload = readBooleanAttr(el, "auto-reload");
  const recompileMode = readRecompile(el.getAttribute("recompile"));
  const merged: JibeEmbedDisplayOptions = {
    ...base,
    ...(showNavigator === undefined ? {} : { showNavigator }),
    ...(showTabs === undefined ? {} : { showTabs }),
    ...(showLineNumbers === undefined ? {} : { showLineNumbers }),
    ...(showConsole === undefined ? {} : { showConsole }),
    ...(showTests === undefined ? {} : { showTests }),
    ...(showAssistant === undefined ? {} : { showAssistant }),
    ...(maxConsoleMessages === undefined ? {} : { maxConsoleMessages }),
    ...(showReadOnly === undefined ? {} : { showReadOnly }),
    ...(closableTabs === undefined ? {} : { closableTabs }),
    ...(wrapContent === undefined ? {} : { wrapContent }),
    ...(fontSize === undefined ? {} : { fontSize }),
    ...(autoReload === undefined ? {} : { autoReload }),
    ...(recompileMode === undefined ? {} : { recompileMode }),
  };
  return Object.keys(merged).length > 0 ? merged : undefined;
}

export function readTheme(
  el: Element,
  base: JibeEmbedOptions["theme"],
): JibeEmbedOptions["theme"] | undefined {
  const preset = readPreset(el.getAttribute("theme"));
  const bg = readStringAttr(el, "theme-bg");
  const fg = readStringAttr(el, "theme-fg");
  const accent = readStringAttr(el, "theme-accent");
  const surface = readStringAttr(el, "theme-surface");
  const muted = readStringAttr(el, "theme-muted");
  const border = readStringAttr(el, "theme-border");
  const fontFamily = readStringAttr(el, "theme-font");
  const previewBg = readStringAttr(el, "theme-preview-bg");
  const fontSize = readNumberAttr(el.getAttribute("font-size"));
  const merged: NonNullable<JibeEmbedOptions["theme"]> = {
    ...base,
    ...(preset === undefined ? {} : { preset }),
    ...(bg === undefined ? {} : { bg }),
    ...(fg === undefined ? {} : { fg }),
    ...(accent === undefined ? {} : { accent }),
    ...(surface === undefined ? {} : { surface }),
    ...(muted === undefined ? {} : { muted }),
    ...(border === undefined ? {} : { border }),
    ...(fontFamily === undefined ? {} : { fontFamily }),
    ...(previewBg === undefined ? {} : { previewBg }),
    ...(fontSize === undefined ? {} : { fontSize }),
  };
  return Object.keys(merged).length > 0 ? merged : undefined;
}

export interface LiveConfigPatch {
  readonly view?: EmbedView;
  readonly chrome?: EmbedChrome;
  readonly activeFile?: string;
  readonly readOnly?: boolean;
  readonly theme?: NonNullable<JibeEmbedOptions["theme"]>;
  readonly options?: {
    readonly showNavigator?: boolean;
    readonly showTabs?: boolean;
    readonly showConsole?: boolean;
    readonly showLineNumbers?: boolean;
    readonly closableTabs?: boolean;
    readonly wrapContent?: boolean;
    readonly showTests?: boolean;
    readonly showAssistant?: boolean;
  };
}

export function readLiveConfig(
  el: Element,
  baseTheme: JibeEmbedOptions["theme"],
  baseOptions?: JibeEmbedDisplayOptions,
): LiveConfigPatch {
  const view = readView(el.getAttribute("view"));
  const chrome = readChrome(el.getAttribute("chrome"));
  const activeFile = readStringAttr(el, "file");
  const readOnly = readBooleanAttr(el, "readonly");
  const theme = readTheme(el, baseTheme);
  const d = readDisplayOptions(el, baseOptions);
  const options =
    d === undefined
      ? undefined
      : {
          ...(d.showNavigator === undefined
            ? {}
            : { showNavigator: d.showNavigator }),
          ...(d.showTabs === undefined ? {} : { showTabs: d.showTabs }),
          ...(d.showConsole === undefined
            ? {}
            : { showConsole: d.showConsole }),
          ...(d.showLineNumbers === undefined
            ? {}
            : { showLineNumbers: d.showLineNumbers }),
          ...(d.closableTabs === undefined
            ? {}
            : { closableTabs: d.closableTabs }),
          ...(d.wrapContent === undefined
            ? {}
            : { wrapContent: d.wrapContent }),
          ...(d.showTests === undefined ? {} : { showTests: d.showTests }),
          ...(d.showAssistant === undefined
            ? {}
            : { showAssistant: d.showAssistant }),
        };
  return {
    ...(view === undefined ? {} : { view }),
    ...(chrome === undefined ? {} : { chrome }),
    ...(activeFile === undefined ? {} : { activeFile }),
    ...(readOnly === undefined ? {} : { readOnly }),
    ...(theme === undefined ? {} : { theme }),
    ...(options !== undefined && Object.keys(options).length > 0
      ? { options }
      : {}),
  };
}

export const LIVE_CONFIGURABLE_ATTRIBUTES: Record<string, true> = {
  view: true,
  chrome: true,
  file: true,
  readonly: true,
  "show-navigator": true,
  "show-tabs": true,
  "show-console": true,
  "show-line-numbers": true,
  "closable-tabs": true,
  "wrap-content": true,
  "show-tests": true,
  "show-assistant": true,
  theme: true,
  "theme-bg": true,
  "theme-fg": true,
  "theme-accent": true,
  "theme-surface": true,
  "theme-muted": true,
  "theme-border": true,
  "theme-font": true,
  "theme-preview-bg": true,
  "font-size": true,
};

export interface ElementPropertyState {
  readonly files: JibeEmbedOptions["files"] | undefined;
  readonly from: JibeEmbedOptions["from"] | undefined;
  readonly visibleFiles: ReadonlyArray<string> | undefined;
  readonly externalResources: ReadonlyArray<string> | undefined;
  readonly options: JibeEmbedDisplayOptions | undefined;
  readonly theme: JibeEmbedOptions["theme"] | undefined;
}

export function readMountOptions(
  el: Element,
  props: ElementPropertyState,
): Omit<
  JibeEmbedOptions,
  | "onFork"
  | "onReady"
  | "onError"
  | "onConsole"
  | "onTestComplete"
  | "onAssistant"
> {
  const view = readView(el.getAttribute("view"));
  const chrome = readChrome(el.getAttribute("chrome"));
  const forkHref = readStringAttr(el, "fork-href");
  const fork = readBooleanAttr(el, "fork");
  const bundler = readBundler(el.getAttribute("bundler"));
  const engine = readEngine(el.getAttribute("engine"));
  const storage = readStorage(el.getAttribute("storage"));
  const activeFile = readStringAttr(el, "file");
  const template = readTemplate(el.getAttribute("template"));
  const from = props.from ?? readStringAttr(el, "from");
  const workspaceId = readStringAttr(el, "workspace-id");
  const readOnly = readBooleanAttr(el, "readonly");
  const visibleFiles =
    props.visibleFiles ?? readCsvAttr(el.getAttribute("visible-files"));
  const showTabs = readBooleanAttr(el, "show-tabs");
  const editorHeight = readNumberAttr(el.getAttribute("editor-height"));
  const recompileDelay = readNumberAttr(el.getAttribute("recompile-delay"));
  const externalResources =
    props.externalResources ??
    readCsvAttr(el.getAttribute("external-resources"));
  const debug = readBooleanAttr(el, "debug");
  const displayOptions = readDisplayOptions(el, props.options);
  const theme = readTheme(el, props.theme);
  const embedOrigin = readStringAttr(el, "embed-origin");
  return {
    ...(embedOrigin === undefined ? {} : { embedOrigin }),
    ...(workspaceId === undefined ? {} : { workspaceId }),
    ...(bundler === undefined ? {} : { bundler }),
    ...(engine === undefined ? {} : { engine }),
    ...(storage === undefined ? {} : { storage }),
    ...(view === undefined ? {} : { view }),
    ...(chrome === undefined ? {} : { chrome }),
    ...(forkHref === undefined
      ? fork === false
        ? { fork: false as const }
        : {}
      : { fork: { href: forkHref } }),
    ...(activeFile === undefined ? {} : { activeFile }),
    ...(from === undefined ? {} : { from }),
    ...(template === undefined ? {} : { template }),
    ...(props.files === undefined ? {} : { files: props.files }),
    ...(readOnly === undefined ? {} : { readOnly }),
    ...(visibleFiles === undefined ? {} : { visibleFiles }),
    ...(showTabs === undefined ? {} : { showTabs }),
    ...(editorHeight === undefined ? {} : { editorHeight }),
    ...(recompileDelay === undefined ? {} : { recompileDelay }),
    ...(externalResources === undefined ? {} : { externalResources }),
    ...(displayOptions === undefined ? {} : { options: displayOptions }),
    ...(theme === undefined ? {} : { theme }),
    ...(debug === undefined ? {} : { debug }),
  };
}
