// packages/embed/src/react.ts — the React binding.
//
// `createJibeEmbed` owns the iframe; React owns the element it mounts into.
// The component re-mounts only when the seed or display options change, and
// callbacks are read from a ref the sync effect keeps current, so an inline
// arrow never tears the workspace down.
import {
  createElement,
  useEffect,
  useRef,
  type CSSProperties,
  type ReactElement,
} from "react";
import {
  createJibeEmbed,
  type EmbedFailureInfo,
  type EmbedSnapshot,
  type JibeEmbedConsoleEntry,
  type JibeEmbedHandle,
  type JibeEmbedOptions,
} from "./sdk.ts";

export interface JibeEmbedProps extends JibeEmbedOptions {
  /** Height of the mount box. Defaults to `"100%"`. */
  readonly height?: number | string;
  readonly className?: string;
  readonly style?: CSSProperties;
}

interface Callbacks {
  readonly onFork: ((snapshot: EmbedSnapshot) => void) | undefined;
  readonly onReady: ((handle: JibeEmbedHandle) => void) | undefined;
  readonly onError: ((failure: EmbedFailureInfo) => void) | undefined;
  readonly onConsole: ((entry: JibeEmbedConsoleEntry) => void) | undefined;
}

/** The options that change what the frame boots with; callbacks excluded. */
function seedSignature(options: JibeEmbedOptions): string {
  return JSON.stringify({
    embedOrigin: options.embedOrigin,
    workspaceId: options.workspaceId,
    bundler: options.bundler,
    from: options.from,
    template: options.template,
    files: options.files,
    externalResources: options.externalResources,
    storage: options.storage,
    fork: options.fork,
    forkCallback: options.onFork !== undefined,
    readyCallback: options.onReady !== undefined,
    errorCallback: options.onError !== undefined,
    debug: options.debug,
  });
}

export function JibeEmbed(props: JibeEmbedProps): ReactElement {
  const host = useRef<HTMLDivElement | null>(null);
  const callbacks = useRef<Callbacks>({
    onFork: props.onFork,
    onReady: props.onReady,
    onError: props.onError,
    onConsole: props.onConsole,
  });
  const signature = seedSignature(props);

  useEffect(() => {
    callbacks.current = {
      onFork: props.onFork,
      onReady: props.onReady,
      onError: props.onError,
      onConsole: props.onConsole,
    };
  });

  const handleRef = useRef<JibeEmbedHandle | null>(null);

  useEffect(() => {
    const node = host.current;
    if (node === null) return;
    let cancelled = false;
    let handle: JibeEmbedHandle | null = null;
    void createJibeEmbed(node, {
      ...props,
      onFork: (snapshot) => callbacks.current.onFork?.(snapshot),
      onReady: (mounted) => callbacks.current.onReady?.(mounted),
      onError: (failure) => callbacks.current.onError?.(failure),
      onConsole: (entry) => callbacks.current.onConsole?.(entry),
    }).then(
      (mounted) => {
        if (cancelled) {
          mounted.destroy();
          return;
        }
        handle = mounted;
        handleRef.current = mounted;
      },
      () => {
        /* onError already reported it */
      },
    );
    return () => {
      cancelled = true;
      handle?.destroy();
      handle = null;
      if (handleRef.current === handle) handleRef.current = null;
    };
    // `signature` is the serialized seed: remount only when the frame's
    // inputs change, never on a re-render.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [signature]);

  // Non-seed prop changes (view, chrome, activeFile, readOnly, theme) go
  // through the existing handle with zero iframe remounts.
  useEffect(() => {
    const handle = handleRef.current;
    if (handle === null) return;
    void handle.configure({
      view: props.view,
      chrome: props.chrome,
      activeFile: props.activeFile,
      readOnly: props.readOnly,
      theme: props.theme,
    });
  }, [props.view, props.chrome, props.activeFile, props.readOnly, props.theme]);

  return createElement("div", {
    ref: host,
    className: props.className,
    style: {
      width: "100%",
      height: props.height ?? "100%",
      overflow: "hidden",
      ...props.style,
    },
  });
}
