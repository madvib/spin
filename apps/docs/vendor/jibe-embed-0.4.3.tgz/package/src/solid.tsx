/** @jsxImportSource @solidjs/web */
// packages/embed/src/solid.tsx — the Solid binding.
//
// Source-first like every other `@jibe/embed` entry: the consumer's Solid
// compiler emits the DOM. The component re-mounts on seed identity and reads
// callbacks through tracked props, so inline handlers never tear down the
// workspace.
import { createEffect } from "solid-js";
import type { JSX } from "@solidjs/web";
import {
  createJibeEmbed,
  type EmbedFailureInfo,
  type EmbedSnapshot,
  type JibeEmbedConsoleEntry,
  type JibeEmbedHandle,
  type JibeEmbedOptions,
} from "./sdk.ts";

export interface JibeEmbedProps extends JibeEmbedOptions {
  /** Height of the mount box. Defaults to `"100%"`. */
  readonly height?: number | string;
  readonly class?: string;
  readonly style?: JSX.CSSProperties;
}

function seedSignature(options: JibeEmbedOptions): string {
  return JSON.stringify({
    embedOrigin: options.embedOrigin,
    workspaceId: options.workspaceId,
    bundler: options.bundler,
    from: options.from,
    template: options.template,
    files: options.files,
    externalResources: options.externalResources,
    storage: options.storage,
    fork: options.fork,
    forkCallback: options.onFork !== undefined,
    readyCallback: options.onReady !== undefined,
    errorCallback: options.onError !== undefined,
    debug: options.debug,
  });
}

export function JibeEmbed(props: JibeEmbedProps): JSX.Element {
  let host: HTMLDivElement | undefined;
  let mounted: JibeEmbedHandle | null = null;

  // Split-phase: the compute reads the seed and the host element; the body
  // runs when either changes and returns its own teardown.
  createEffect(
    () => ({ signature: seedSignature(props), node: host }),
    (deps) => {
      void deps.signature;
      const node = deps.node;
      if (node === undefined) return undefined;
      let cancelled = false;
      mounted?.destroy();
      mounted = null;
      const fork = (snapshot: EmbedSnapshot): void => {
        props.onFork?.(snapshot);
      };
      const ready = (handle: JibeEmbedHandle): void => {
        props.onReady?.(handle);
      };
      const fail = (failure: EmbedFailureInfo): void => {
        props.onError?.(failure);
      };
      const log = (entry: JibeEmbedConsoleEntry): void => {
        props.onConsole?.(entry);
      };
      void createJibeEmbed(node, {
        ...props,
        onFork: fork,
        onReady: ready,
        onError: fail,
        onConsole: log,
      }).then(
        (handle) => {
          if (cancelled) {
            handle.destroy();
            return;
          }
          mounted = handle;
        },
        () => {
          /* onError already reported it */
        },
      );
      return (): void => {
        cancelled = true;
        mounted?.destroy();
        mounted = null;
      };
    },
  );

  // Non-seed prop changes (view, chrome, activeFile, readOnly, theme) go
  // through the existing handle with zero iframe remounts.
  createEffect(
    () => ({
      view: props.view,
      chrome: props.chrome,
      activeFile: props.activeFile,
      readOnly: props.readOnly,
      theme: props.theme,
    }),
    (live) => {
      if (mounted === null) return;
      void mounted.configure({
        view: live.view,
        chrome: live.chrome,
        activeFile: live.activeFile,
        readOnly: live.readOnly,
        theme: live.theme,
      });
    },
  );

  return (
    <div
      ref={(el) => {
        host = el;
      }}
      class={props.class}
      style={{
        width: "100%",
        height:
          typeof props.height === "number"
            ? `${props.height}px`
            : (props.height ?? "100%"),
        overflow: "hidden",
        ...props.style,
      }}
    />
  );
}
