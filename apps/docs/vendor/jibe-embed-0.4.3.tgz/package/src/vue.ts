// packages/embed/src/vue.ts — the Vue binding.
//
// A render-function component: Vue owns the mount box, `createJibeEmbed`
// owns the iframe. `options` is watched shallowly by seed identity, so a
// component re-render never restarts the workspace.
import {
  defineComponent,
  h,
  onBeforeUnmount,
  onMounted,
  ref,
  watch,
  type PropType,
  type VNode,
} from "vue";
import {
  createJibeEmbed,
  type EmbedFailureInfo,
  type EmbedSnapshot,
  type JibeEmbedConsoleEntry,
  type JibeEmbedHandle,
  type JibeEmbedOptions,
} from "./sdk.ts";

export interface JibeEmbedProps {
  /** Seed, display, and theme options for the mounted workspace. */
  readonly options: JibeEmbedOptions;
  /** Height of the mount box. Defaults to `"100%"`. */
  readonly height?: number | string;
}

function seedSignature(options: JibeEmbedOptions): string {
  return JSON.stringify({
    embedOrigin: options.embedOrigin,
    workspaceId: options.workspaceId,
    bundler: options.bundler,
    from: options.from,
    template: options.template,
    files: options.files,
    externalResources: options.externalResources,
    storage: options.storage,
  });
}

function liveSignature(options: JibeEmbedOptions): string {
  return JSON.stringify({
    view: options.view,
    chrome: options.chrome,
    activeFile: options.activeFile,
    readOnly: options.readOnly,
    theme: options.theme,
  });
}

export const JibeEmbed = defineComponent({
  name: "JibeEmbed",
  props: {
    options: {
      type: Object as PropType<JibeEmbedOptions>,
      required: true,
    },
    height: {
      type: [Number, String] as PropType<number | string>,
      default: "100%",
    },
  },
  emits: {
    ready: (_handle: JibeEmbedHandle): boolean => true,
    fork: (_snapshot: EmbedSnapshot): boolean => true,
    "embed-error": (_failure: EmbedFailureInfo): boolean => true,
    console: (_entry: JibeEmbedConsoleEntry): boolean => true,
  },
  setup(props, { emit, expose }): () => VNode {
    const host = ref<HTMLElement | null>(null);
    let handle: JibeEmbedHandle | null = null;
    let generation = 0;
    let lastSeed = seedSignature(props.options);
    let lastLive = liveSignature(props.options);

    const configureLive = (): void => {
      if (handle === null) return;
      const options = props.options;
      void handle.configure({
        view: options.view,
        chrome: options.chrome,
        activeFile: options.activeFile,
        readOnly: options.readOnly,
        theme: options.theme,
      });
    };

    const mount = (): void => {
      const node = host.value;
      if (node === null) return;
      generation += 1;
      const mine = generation;
      handle?.destroy();
      handle = null;
      void createJibeEmbed(node, {
        ...props.options,
        onReady: (mounted) => {
          if (mine !== generation) return;
          emit("ready", mounted);
        },
        onFork: (snapshot) => {
          if (mine !== generation) return;
          emit("fork", snapshot);
        },
        onError: (failure) => {
          if (mine !== generation) return;
          emit("embed-error", failure);
        },
        onConsole: (entry) => {
          if (mine !== generation) return;
          emit("console", entry);
        },
      }).then(
        (mounted) => {
          if (mine !== generation) {
            mounted.destroy();
            return;
          }
          handle = mounted;
          lastLive = liveSignature(props.options);
        },
        () => {
          /* onError already reported it */
        },
      );
    };

    onMounted(mount);
    watch(
      () => props.options,
      () => {
        const seed = seedSignature(props.options);
        if (seed !== lastSeed) {
          lastSeed = seed;
          lastLive = liveSignature(props.options);
          mount();
          return;
        }
        const live = liveSignature(props.options);
        if (live !== lastLive) {
          lastLive = live;
          configureLive();
        }
      },
      { deep: true },
    );
    onBeforeUnmount(() => {
      generation += 1;
      handle?.destroy();
      handle = null;
    });
    expose({
      get handle(): JibeEmbedHandle | null {
        return handle;
      },
    });

    return (): VNode =>
      h("div", {
        ref: host,
        style: {
          width: "100%",
          height:
            typeof props.height === "number"
              ? `${props.height}px`
              : props.height,
          overflow: "hidden",
        },
      });
  },
});
