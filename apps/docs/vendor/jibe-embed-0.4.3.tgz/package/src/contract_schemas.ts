// packages/embed/src/contract_schemas.ts — valibot boundary schemas for embed.
import * as v from "valibot";

export type EmbedBundlerMode = "off" | "lazy" | "eager";

export type EmbedEngine = "rolldown" | "lite" | "auto";

export const diagnosticSchema = v.strictObject({
  path: v.string(),
  severity: v.picklist(["error", "warn"]),
  code: v.picklist([
    "unsupported-node-builtin",
    "unsupported-native-addon",
    "unsupported-server-plugin",
    "unsupported-server-only",
    "secret-env",
    "uninlined-env",
    "resolve-error",
    "resolve-subpath",
    "unsupported-range",
    "resolve-warning",
    "missing-entry",
    "missing-compiler",
    "bundle-error",
    "plugin-warning",
  ]),
  message: v.string(),
  remediation: v.optional(v.string()),
});

export const compatSeamSchema = v.strictObject({
  kind: v.picklist([
    "vfs-sandbox",
    "node-polyfill",
    "browser-condition",
    "cjs-interop",
    "mixed-vite-plugin",
  ]),
  specifier: v.string(),
  detail: v.string(),
});

export const compatibilitySchema = v.strictObject({
  status: v.picklist(["supported", "seam", "refused"]),
  seams: v.array(compatSeamSchema),
  diagnostics: v.array(diagnosticSchema),
});

export const embedSourceSchema = v.variant("kind", [
  v.strictObject({
    kind: v.literal("files"),
    files: v.record(v.string(), v.string()),
  }),
  v.strictObject({ kind: v.literal("snapshot"), url: v.string() }),
  v.strictObject({ kind: v.literal("tarball"), url: v.string() }),
  v.strictObject({
    kind: v.literal("github"),
    repo: v.string(),
    ref: v.optional(v.string()),
    subpath: v.optional(v.string()),
  }),
]);

export type EmbedSource = v.InferOutput<typeof embedSourceSchema>;

export const embedThemeSchema = v.strictObject({
  preset: v.optional(v.picklist(["dark", "light"])),
  bg: v.optional(v.string()),
  fg: v.optional(v.string()),
  accent: v.optional(v.string()),
  surface: v.optional(v.string()),
  muted: v.optional(v.string()),
  border: v.optional(v.string()),
  fontFamily: v.optional(v.string()),
  previewBg: v.optional(v.string()),
  fontSize: v.optional(v.number()),
});

export type EmbedTheme = v.InferOutput<typeof embedThemeSchema>;

export const embedLiveOptionsSchema = v.strictObject({
  showNavigator: v.optional(v.boolean()),
  showTabs: v.optional(v.boolean()),
  showConsole: v.optional(v.boolean()),
  showLineNumbers: v.optional(v.boolean()),
  closableTabs: v.optional(v.boolean()),
  wrapContent: v.optional(v.boolean()),
  showTests: v.optional(v.boolean()),
  showAssistant: v.optional(v.boolean()),
});

export type EmbedLiveOptions = v.InferOutput<typeof embedLiveOptionsSchema>;

export const embedConfigureInputSchema = v.strictObject({
  view: v.optional(v.picklist(["split", "preview", "code"])),
  chrome: v.optional(
    v.picklist(["studio", "preview", "minimal", "none", "ide"]),
  ),
  activeFile: v.optional(v.string()),
  readOnly: v.optional(v.boolean()),
  theme: v.optional(embedThemeSchema),
  options: v.optional(embedLiveOptionsSchema),
});
export type EmbedConfigureInput = v.InferOutput<
  typeof embedConfigureInputSchema
>;

export const embedConfigureOutputSchema = v.strictObject({
  view: v.picklist(["split", "preview", "code"]),
  chrome: v.picklist(["studio", "preview", "minimal", "none", "ide"]),
  activeFile: v.string(),
  readOnly: v.boolean(),
});

export type EmbedConfigureOutput = v.InferOutput<
  typeof embedConfigureOutputSchema
>;

export const embedResetInputSchema = v.strictObject({
  files: v.optional(v.record(v.string(), v.string())),
  activeFile: v.optional(v.string()),
});

export type EmbedResetInput = v.InferOutput<typeof embedResetInputSchema>;

export const embedResetOutputSchema = v.strictObject({
  files: v.array(v.string()),
  activeFile: v.string(),
  bundlerLoaded: v.boolean(),
  diagnostics: v.array(diagnosticSchema),
});

export type EmbedResetOutput = v.InferOutput<typeof embedResetOutputSchema>;

export const embedTestCaseSchema = v.strictObject({
  suite: v.string(),
  name: v.string(),
  passed: v.boolean(),
  durationMs: v.number(),
  error: v.optional(v.string()),
});
export const embedTestFileSchema = v.strictObject({
  file: v.string(),
  passed: v.number(),
  failed: v.number(),
  cases: v.array(embedTestCaseSchema),
});
export const embedTestOutcomeSchema = v.strictObject({
  passed: v.number(),
  failed: v.number(),
  files: v.array(embedTestFileSchema),
});
export type EmbedTestOutcome = v.InferOutput<typeof embedTestOutcomeSchema>;

export interface EmbedInitState {
  readonly visibleFiles: ReadonlyArray<string> | null;
  readonly readOnlyFiles: ReadonlyArray<string>;
  readonly activeFile?: string;
  readonly initialFiles?: Readonly<Record<string, string>>;
  readonly externalResources?: ReadonlyArray<string>;
}
