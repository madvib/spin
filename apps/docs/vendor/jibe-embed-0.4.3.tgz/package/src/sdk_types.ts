// packages/embed/src/sdk_types.ts — shared consumer-SDK surface types.
//
// Value-free module: every `JibeEmbedOptions` supporting type plus the slot
// mount seed. `sdk.ts` re-exports the public names so existing imports keep
// working; `sdk_url.ts` / `sdk_mount.ts` / `sdk_slot.ts` import from here.
import type {
  EmbedBundlerMode,
  EmbedEngine,
  EmbedConfigureInput,
  EmbedConfigureOutput,
  EmbedResetInput,
  EmbedResetOutput,
  EmbedSource,
  EmbedTheme,
} from "./contract.ts";
import type { EmbedFailure } from "./failures.ts";
import type { ContractRouterClient } from "@orpc/contract";
import { embedContract } from "./contract.ts";

export type EmbedView = "split" | "preview" | "code";

/**
 * How much frame chrome the embed draws.
 *
 * `studio` — editor, file tabs, navigator, console, and the full action bar.
 * `preview` — the running app plus the console drawer, no editor.
 * `minimal` — the running app and the Fork watermark, nothing else.
 * `none` — the running app, edge to edge.
 * `ide` — the full editor: navigator, buffers, code, preview, and console.
 */
export type EmbedChrome = "studio" | "preview" | "minimal" | "none" | "ide";

/** The workspace as the reader sees it at fork time. */
export interface EmbedSnapshot {
  readonly files: Readonly<Record<string, string>>;
  readonly lock: string | null;
}

/**
 * A failure the consumer can switch on. `kind` is a closed taxonomy
 * (`@jibe/embed` failure kinds) or `null` when the host reported an error
 * the SDK could not classify.
 */
export interface EmbedFailureInfo {
  readonly kind: EmbedFailure | null;
  readonly message: string;
}

export type EmbedFileInput =
  | string
  | {
      readonly code: string;
      readonly readOnly?: boolean;
      readonly hidden?: boolean;
      readonly active?: boolean;
    };

export interface JibeEmbedConsoleEntry {
  readonly level: "log" | "info" | "warn" | "error";
  readonly args: ReadonlyArray<string>;
  readonly timestamp: number;
}

export interface EmbedAssistantMessage {
  readonly role: "user" | "assistant" | "tool";
  readonly text: string;
  readonly toolName?: string;
}

export interface EmbedAssistantToolDef {
  readonly name: string;
  readonly description: string;
  readonly inputSchema: Readonly<Record<string, unknown>>;
}

/** What the frame sends the parent when the reader chats. */
export interface EmbedAssistantRequest {
  readonly workspaceId: string;
  readonly thread: ReadonlyArray<EmbedAssistantMessage>;
  readonly tools: ReadonlyArray<EmbedAssistantToolDef>;
  readonly reply: (text: string) => void;
}

export interface JibeEmbedDisplayOptions {
  /**
   * Show the file tree navigator. Defaults to `true`; pass `false` to hide
   * (emits `nav=0`).
   */
  readonly showNavigator?: boolean;
  /**
   * Show file tabs. Defaults to `true`; falls back to the legacy top-level
   * `showTabs`. Pass `false` to hide (emits `showtabs=0`).
   */
  readonly showTabs?: boolean;
  /**
   * Show line numbers in the editor. Defaults to `true`; pass `false` to hide
   * (emits `linenos=0`).
   */
  readonly showLineNumbers?: boolean;
  /**
   * Show the console/problems drawer bar. Defaults to `true`; pass `false` to
   * hide (emits `console=0`).
   */
  readonly showConsole?: boolean;
  /**
   * Show the Tests drawer tab. Defaults to `true`; pass `false` to hide
   * (emits `testsui=0`).
   */
  readonly showTests?: boolean;
  /**
   * Show the assistant region. Defaults to `false`; pass `true` to show
   * (emits `assistant=1`). The panel needs a model hook (`onAssistant`)
   * or it shows its empty state.
   */
  readonly showAssistant?: boolean;
  /**
   * Cap console entries retained in the drawer. Defaults to 200; emits
   * `maxconsole=N`.
   */
  readonly maxConsoleMessages?: number;
  /**
   * Show the read-only chip. Defaults to `true`; pass `false` to hide
   * (emits `rochip=0`).
   */
  readonly showReadOnly?: boolean;
  /**
   * Allow closing file tabs via their × button. Defaults to `true`; pass
   * `false` to hide the close buttons (emits `closable=0`).
   */
  readonly closableTabs?: boolean;
  /**
   * Wrap long lines in the editor. Defaults to `false`; pass `true` to enable
   * (emits `wrap=1`).
   */
  readonly wrapContent?: boolean;
  /**
   * Editor font size in pixels. Unset by default. Emits `fontsize=N`.
   * `theme.fontSize` is an alias; `options.fontSize` wins.
   */
  readonly fontSize?: number;
  /**
   * Auto-reload the preview on file changes (HMR). Defaults to `true`; pass
   * `false` to skip (emits `autoreload=0`).
   */
  readonly autoReload?: boolean;
  /**
   * Recompile strategy. `"auto"` (default) or `"manual"` (emits
   * `recompile=manual`).
   */
  readonly recompileMode?: "auto" | "manual";
  /**
   * Show the Jibe wordmark in the header. Defaults to visible; pass `false`
   * to hide (emits `brand=0`). No custom-brand option.
   */
  readonly brand?: false;
}

/**
 * Where an embed's workspace lives.
 *
 * `"memory"` keeps the workspace in the frame for the session: no storage
 * directory, no restore on reload, no accumulation across jibes. `"opfs"` is
 * the flagship's shared workspace. Embeds default to memory; a host that
 * wants a surviving workspace opts in.
 */
export type EmbedStorage = "memory" | "opfs";

/**
 * Seed selection for `JibeEmbedOptions["from"]`: a tarball URL, a snapshot
 * URL, or a `{ repo }` GitHub tarball. The contract wire format keeps `kind`
 * (machines); this surface drops it (humans).
 */
export type EmbedFromSource =
  | string
  | {
      readonly repo: string;
      readonly ref?: string;
      readonly subpath?: string;
    };

export interface JibeEmbedHandle {
  readonly iframe: HTMLIFrameElement;
  readonly workspaceId: string;
  readonly client: ContractRouterClient<typeof embedContract>;
  readonly reset: (input?: EmbedResetInput) => Promise<EmbedResetOutput>;
  readonly configure: (
    patch: EmbedConfigureInput,
  ) => Promise<EmbedConfigureOutput>;
  readonly setView: (view: EmbedView) => Promise<EmbedConfigureOutput>;
  readonly setTheme: (theme: EmbedTheme) => Promise<EmbedConfigureOutput>;
  readonly setActiveFile: (path: string) => Promise<EmbedConfigureOutput>;
  readonly destroy: () => void;
}

/** Resolved mount inputs: everything `mountEmbedFrame` needs besides options. */
export interface EmbedMountSeed {
  readonly embedOrigin: string;
  readonly targetOrigin: string;
  readonly params: URLSearchParams;
  readonly workspaceId: string;
  readonly bundler: EmbedBundlerMode;
  readonly engine: EmbedEngine;
  readonly view: EmbedView;
  readonly overlayFiles: Record<string, string>;
  readonly overlayHidden: ReadonlyArray<string>;
  readonly overlayReadOnly: ReadonlyArray<string>;
  readonly activeFile: string | undefined;
  readonly fromSource: EmbedSource | undefined;
}

/** One live frame: the iframe, its RPC client, and its teardown handles. */
export interface SlotMount {
  readonly iframe: HTMLIFrameElement;
  readonly client: ContractRouterClient<typeof embedContract>;
  readonly channel: MessageChannel;
  readonly listener: (event: MessageEvent) => void;
}
