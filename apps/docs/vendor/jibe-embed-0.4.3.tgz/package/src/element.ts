// packages/embed/src/element.ts — the `<jibe-embed>` custom element.
//
// Attribute- and property-driven custom element over `createJibeEmbed`:
// `<jibe-embed template="react">` boots on connect and destroys on
// disconnect. Every `JibeEmbedOptions`, `JibeEmbedDisplayOptions`, and
// `theme` field is configurable via HTML attributes and DOM properties
// (`files`, `from`, `visibleFiles`, `externalResources`, `options`,
// `theme`). Attribute and property changes post-mount remount
// generation-safely. Attribute parsing lives in `element_attrs.ts`.
import {
  LIVE_CONFIGURABLE_ATTRIBUTES,
  readLiveConfig,
  readMountOptions,
  readTheme,
} from "./element_attrs.ts";
import {
  createJibeEmbed,
  type EmbedFileInput,
  type JibeEmbedDisplayOptions,
  type JibeEmbedHandle,
  type JibeEmbedOptions,
} from "./sdk.ts";

export const OBSERVED_ATTRIBUTES = [
  "embed-origin",
  "view",
  "chrome",
  "fork",
  "fork-href",
  "bundler",
  "engine",
  "storage",
  "file",
  "template",
  "from",
  "workspace-id",
  "readonly",
  "visible-files",
  "show-tabs",
  "editor-height",
  "recompile-delay",
  "external-resources",
  "debug",
  "show-navigator",
  "show-line-numbers",
  "show-console",
  "show-tests",
  "show-assistant",
  "max-console-messages",
  "show-readonly",
  "closable-tabs",
  "wrap-content",
  "font-size",
  "auto-reload",
  "recompile",
  "theme",
  "theme-bg",
  "theme-fg",
  "theme-accent",
  "theme-surface",
  "theme-muted",
  "theme-border",
  "theme-font",
  "theme-preview-bg",
] as const;

export interface JibeEmbedElement extends HTMLElement {
  files: Record<string, EmbedFileInput> | undefined;
  from: JibeEmbedOptions["from"] | undefined;
  visibleFiles: ReadonlyArray<string> | undefined;
  externalResources: ReadonlyArray<string> | undefined;
  options: JibeEmbedDisplayOptions | undefined;
  theme: JibeEmbedOptions["theme"] | undefined;
  readonly handle: Promise<JibeEmbedHandle>;
}

const TAG_DEFAULT = "jibe-embed";

export function defineJibeEmbed(tag: string = TAG_DEFAULT): void {
  if (customElements.get(tag) !== undefined) return;
  customElements.define(
    tag,
    class extends HTMLElement {
      #files: Record<string, EmbedFileInput> | undefined = undefined;
      #from: JibeEmbedOptions["from"] | undefined = undefined;
      #visibleFiles: ReadonlyArray<string> | undefined = undefined;
      #externalResources: ReadonlyArray<string> | undefined = undefined;
      #options: JibeEmbedDisplayOptions | undefined = undefined;
      #theme: JibeEmbedOptions["theme"] | undefined = undefined;
      #handle: Promise<JibeEmbedHandle> | null = null;
      #settled: JibeEmbedHandle | null = null;
      #mountedOrigin: string | null = null;
      #mountStarted = false;
      #generation = 0;

      static get observedAttributes(): ReadonlyArray<string> {
        return OBSERVED_ATTRIBUTES;
      }

      get files(): Record<string, EmbedFileInput> | undefined {
        return this.#files;
      }

      #runLive(fn: (handle: JibeEmbedHandle) => void): boolean {
        if (!this.#mountStarted || this.#handle === null) return false;
        const gen = this.#generation;
        void this.#handle.then((handle) => {
          if (this.#generation === gen) fn(handle);
        });
        return true;
      }

      set files(value: Record<string, EmbedFileInput> | undefined) {
        this.#files = value;
        if (
          value !== undefined &&
          this.#runLive((handle) => {
            const plain: Record<string, string> = {};
            let active: string | undefined;
            for (const [k, v] of Object.entries(value)) {
              if (typeof v === "string") plain[k] = v;
              else {
                plain[k] = v.code;
                if (v.active === true && active === undefined) active = k;
              }
            }
            const activeFile = this.getAttribute("file") || active;
            void handle.reset({
              files: plain,
              ...(activeFile === undefined ? {} : { activeFile }),
            });
          })
        ) {
          return;
        }
        if (this.#mountStarted) this.#remount();
      }

      get from(): JibeEmbedOptions["from"] | undefined {
        return this.#from;
      }

      set from(value: JibeEmbedOptions["from"] | undefined) {
        this.#from = value;
        if (this.#mountStarted) this.#remount();
      }

      get visibleFiles(): ReadonlyArray<string> | undefined {
        return this.#visibleFiles;
      }

      set visibleFiles(value: ReadonlyArray<string> | undefined) {
        this.#visibleFiles = value;
        if (this.#mountStarted) this.#remount();
      }

      get externalResources(): ReadonlyArray<string> | undefined {
        return this.#externalResources;
      }

      set externalResources(value: ReadonlyArray<string> | undefined) {
        this.#externalResources = value;
        if (this.#mountStarted) this.#remount();
      }

      get options(): JibeEmbedDisplayOptions | undefined {
        return this.#options;
      }

      set options(value: JibeEmbedDisplayOptions | undefined) {
        this.#options = value;
        if (
          this.#runLive(
            (h) =>
              void h.configure(
                readLiveConfig(this, this.#theme, this.#options),
              ),
          )
        ) {
          return;
        }
        if (this.#mountStarted) this.#remount();
      }

      get theme(): JibeEmbedOptions["theme"] | undefined {
        return this.#theme;
      }

      set theme(value: JibeEmbedOptions["theme"] | undefined) {
        this.#theme = value;
        if (
          this.#runLive((h) => {
            const theme = readTheme(this, this.#theme);
            void h.configure(theme === undefined ? {} : { theme });
          })
        ) {
          return;
        }
        if (this.#mountStarted) this.#remount();
      }

      get handle(): Promise<JibeEmbedHandle> {
        if (this.#handle === null) {
          throw new Error("jibe-embed is not connected");
        }
        return this.#handle;
      }

      attributeChangedCallback(
        name: string,
        oldValue: string | null,
        newValue: string | null,
      ): void {
        if (!this.#mountStarted || oldValue === newValue) return;
        if (name === "embed-origin" && newValue === this.#mountedOrigin) return;
        if (
          LIVE_CONFIGURABLE_ATTRIBUTES[name] === true &&
          this.#runLive(
            (h) =>
              void h.configure(
                readLiveConfig(this, this.#theme, this.#options),
              ),
          )
        ) {
          return;
        }
        this.#remount();
      }

      connectedCallback(): void {
        // Custom elements are `display:inline` by default, which ignores
        // `height` and collapses the mount to a sliver. Default to `block`
        // unless the cascade already placed the element.
        if (
          this.style.display === "" &&
          this.ownerDocument.defaultView?.getComputedStyle(this).display ===
            "inline"
        ) {
          this.style.display = "block";
        }
        // Defer one microtask: `defineJibeEmbed()` upgrades elements already
        // in the DOM, and the caller's next lines set `embed-origin`/`files`
        // before this mount reads them. Elements created after definition
        // (innerHTML/parser) mount on the same tick — no observable delay.
        this.#boot();
      }

      // One mount attempt, generation-guarded: a remount supersedes the
      // in-flight mount. Stale iframes are removed synchronously — a
      // wrong-origin mount can hang until its 30s ready-timeout rejects.
      #boot(): void {
        const generation = this.#generation + 1;
        this.#generation = generation;
        for (const stale of this.querySelectorAll("iframe")) stale.remove();
        const attempt = Promise.resolve().then(() => {
          if (this.#generation !== generation || !this.isConnected) {
            throw new Error("jibe-embed: mount superseded");
          }
          return this.#mount();
        });
        this.#handle = attempt;
        void attempt.then(
          (handle) => {
            if (this.#generation !== generation) {
              handle.destroy();
              return;
            }
            this.#settled = handle;
          },
          () => {},
        );
      }

      #remount(): void {
        this.#settled?.destroy();
        this.#settled = null;
        this.#boot();
      }

      #mount(): Promise<JibeEmbedHandle> {
        this.#mountStarted = true;
        this.#mountedOrigin = this.getAttribute("embed-origin");
        return createJibeEmbed(this, {
          ...readMountOptions(this, {
            files: this.#files,
            from: this.#from,
            visibleFiles: this.#visibleFiles,
            externalResources: this.#externalResources,
            options: this.#options,
            theme: this.#theme,
          }),
          onFork: (snapshot) => {
            this.dispatchEvent(new CustomEvent("fork", { detail: snapshot }));
          },
          onReady: (handle) => {
            this.dispatchEvent(new CustomEvent("ready", { detail: handle }));
          },
          onError: (failure) => {
            this.dispatchEvent(
              new CustomEvent("embed-error", { detail: failure }),
            );
          },
          onConsole: (entry) => {
            this.dispatchEvent(new CustomEvent("console", { detail: entry }));
          },
          onTestComplete: (outcome) => {
            this.dispatchEvent(
              new CustomEvent("tests-complete", { detail: outcome }),
            );
          },
        });
      }

      disconnectedCallback(): void {
        this.#generation += 1;
        for (const stale of this.querySelectorAll("iframe")) stale.remove();
        this.#settled?.destroy();
        this.#settled = null;
        this.#handle = null;
        this.#mountStarted = false;
        this.#mountedOrigin = null;
      }
    },
  );
}
