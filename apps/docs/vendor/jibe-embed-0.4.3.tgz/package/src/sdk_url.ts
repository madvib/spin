// packages/embed/src/sdk_url.ts — embed URL, seed, and DOM helpers.
//
// Pure construction helpers for `createJibeEmbed`: origin resolution, `from`
// mapping, `files` overlay normalization, query-param building, and the two
// tiny DOM helpers (lazy placeholder, iframe allow). No RPC, no lifecycle.
import type { EmbedSource } from "./contract.ts";
import type {
  EmbedFileInput,
  EmbedFromSource,
  EmbedMountSeed,
} from "./sdk_types.ts";
import type { JibeEmbedOptions } from "./sdk.ts";

export function randomWorkspaceId(): string {
  const bytes = new Uint8Array(8);
  crypto.getRandomValues(bytes);
  return [...bytes].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}

export function resolveEmbedOrigin(embedOrigin: string | undefined): {
  readonly embedOrigin: string;
  readonly targetOrigin: string;
} {
  const resolved = embedOrigin ?? "https://embed.jibe.run";
  return { embedOrigin: resolved, targetOrigin: handshakeOriginOf(resolved) };
}

export function handshakeOriginOf(embedOrigin: string): string {
  return new URL(embedOrigin).origin;
}

export function buildEmbedUrl(
  embedOrigin: string,
  params: URLSearchParams,
): string {
  return `${embedOrigin}/embed?${params.toString()}`;
}

// `from` maps onto the contract wire `kind` (machines); `files` overlays
// merge over the seed inside `server.ts` (overlay wins on collision).
export function resolveFromSource(
  from: EmbedFromSource | undefined,
): EmbedSource | undefined {
  if (from === undefined) return undefined;
  if (typeof from === "string") {
    return from.endsWith(".tgz") ||
      from.endsWith(".tar.gz") ||
      from.endsWith(".zip")
      ? { kind: "tarball", url: from }
      : { kind: "snapshot", url: from };
  }
  return {
    kind: "github",
    repo: from.repo,
    ...(from.ref === undefined ? {} : { ref: from.ref }),
    ...(from.subpath === undefined ? {} : { subpath: from.subpath }),
  };
}

export interface NormalizedFiles {
  readonly texts: Record<string, string>;
  readonly readOnly: Array<string>;
  readonly hidden: Array<string>;
  readonly activeFile: string | undefined;
}

export function normalizeFilesRecord(
  files: Readonly<Record<string, EmbedFileInput>> | undefined,
  activeFile: string | undefined,
): NormalizedFiles {
  const texts: Record<string, string> = {};
  const readOnly: Array<string> = [];
  const hidden: Array<string> = [];
  let derived: string | undefined = activeFile;
  if (files === undefined)
    return { texts, readOnly, hidden, activeFile: derived };
  for (const [path, entry] of Object.entries(files)) {
    if (typeof entry === "string") {
      texts[path] = entry;
      continue;
    }
    texts[path] = entry.code;
    if (entry.readOnly === true) readOnly.push(path);
    if (entry.hidden === true) hidden.push(path);
    if (entry.active === true && derived === undefined) derived = path;
  }
  return { texts, readOnly, hidden, activeFile: derived };
}

export function applyIframeAllow(iframe: HTMLIFrameElement): void {
  iframe.setAttribute("allow", "cross-origin-isolated; fullscreen");
  iframe.setAttribute("allowFullscreen", "");
  iframe.setAttribute("title", "Jibe embed");
}

// Resolve every mount input `createSlotDriver` needs besides the options:
// origins, workspace id, bundler/view defaults, overlay normalization, the
// query params, and the `from` source. Fail fast on dual seeds before any
// iframe exists (a valibot error after mount would strand a booting frame).
export function resolveEmbedMountSeed(
  options: JibeEmbedOptions,
): EmbedMountSeed {
  if (options.template !== undefined && options.from !== undefined) {
    throw new Error("choose one seed: template or from");
  }
  const { embedOrigin, targetOrigin } = resolveEmbedOrigin(options.embedOrigin);
  const workspaceId = options.workspaceId ?? randomWorkspaceId();
  const bundler = options.bundler ?? "lazy";
  const engine = options.engine ?? "auto";
  const view = options.view ?? "split";
  const normalized = normalizeFilesRecord(options.files, options.activeFile);
  const overlayFiles = normalized.texts;
  const overlayReadOnly = normalized.readOnly;
  const overlayHidden = normalized.hidden;
  const derivedActiveFile = normalized.activeFile;
  const display = options.options;
  const chrome = options.chrome ?? "studio";
  const showNavigator = display?.showNavigator ?? chrome === "ide";
  const showTabs = display?.showTabs ?? options.showTabs ?? true;
  const showLineNumbers = display?.showLineNumbers ?? true;
  const showConsole = display?.showConsole ?? true;
  const showTests = display?.showTests ?? true;
  const showAssistant = display?.showAssistant ?? false;
  const showReadOnly = display?.showReadOnly ?? true;
  const closableTabs = display?.closableTabs ?? true;
  const wrapContent = display?.wrapContent ?? false;
  const fontSize = display?.fontSize ?? options.theme?.fontSize;
  const autoReload = display?.autoReload ?? true;
  const recompileMode = display?.recompileMode ?? "auto";
  // the consumer gave it a publish destination. Callback-only snapshots stay
  // available via `handle.client` but get no button — no implied backend.
  const forkHref = options.fork === false ? null : (options.fork?.href ?? null);
  const forkEnabled = forkHref !== null;
  const params = new URLSearchParams({
    id: workspaceId,
    bundler,
    engine,
    view,
    chrome,
    parent: window.location.origin,
    ...(forkEnabled ? {} : { fork: "0" }),
    ...(forkHref === null ? {} : { forkhref: forkHref }),
    ...(display?.brand === false ? { brand: "0" } : {}),
    ...(derivedActiveFile === undefined ? {} : { file: derivedActiveFile }),
    storage: options.storage ?? "memory",
    ...(options.template === undefined ? {} : { template: options.template }),
    ...(options.readOnly !== true ? {} : { readonly: "1" }),
    ...(showTabs === false ? { showtabs: "0" } : {}),
    ...(options.editorHeight === undefined
      ? {}
      : { height: String(options.editorHeight) }),
    ...(options.recompileDelay === undefined
      ? {}
      : { redelay: String(options.recompileDelay) }),
    ...(showNavigator === true ? { nav: "1" } : { nav: "0" }),
    ...(showLineNumbers === false ? { linenos: "0" } : {}),
    ...(showConsole === false ? { console: "0" } : {}),
    ...(showTests === false ? { testsui: "0" } : {}),
    ...(showAssistant === true ? { assistant: "1" } : {}),
    ...(display?.maxConsoleMessages === undefined
      ? {}
      : { maxconsole: String(display.maxConsoleMessages) }),
    ...(showReadOnly === false ? { rochip: "0" } : {}),
    ...(closableTabs === false ? { closable: "0" } : {}),
    ...(wrapContent === true ? { wrap: "1" } : {}),
    ...(fontSize === undefined ? {} : { fontsize: String(fontSize) }),
    ...(autoReload === false ? { autoreload: "0" } : {}),
    ...(recompileMode === "manual" ? { recompile: "manual" } : {}),
    ...(options.theme?.preset === undefined
      ? {}
      : { themepreset: options.theme.preset }),
    ...(options.theme?.bg === undefined ? {} : { bg: options.theme.bg }),
    ...(options.theme?.fg === undefined ? {} : { fg: options.theme.fg }),
    ...(options.theme?.accent === undefined
      ? {}
      : { accent: options.theme.accent }),
    ...(options.theme?.surface === undefined
      ? {}
      : { surface: options.theme.surface }),
    ...(options.theme?.muted === undefined
      ? {}
      : { muted: options.theme.muted }),
    ...(options.theme?.border === undefined
      ? {}
      : { border: options.theme.border }),
    ...(options.theme?.previewBg === undefined
      ? {}
      : { previewbg: options.theme.previewBg }),
    ...(options.theme?.fontFamily === undefined
      ? {}
      : { font: options.theme.fontFamily }),
    ...(options.debug !== true ? {} : { debug: "1" }),
  });
  return {
    embedOrigin,
    targetOrigin,
    params,
    workspaceId,
    bundler,
    engine,
    view,
    overlayFiles,
    overlayHidden,
    overlayReadOnly,
    activeFile: derivedActiveFile,
    fromSource: resolveFromSource(options.from),
  };
}
