// packages/embed/src/mod.ts — @jibe/embed public surface.
export {
  embedConfigureInputSchema,
  embedConfigureOutputSchema,
  embedContract,
  embedResetInputSchema,
  embedResetOutputSchema,
  embedSourceSchema,
  embedTestOutcomeSchema,
  embedThemeSchema,
} from "./contract.ts";
export type {
  EmbedBundlerMode,
  EmbedEngine,
  EmbedConfigureInput,
  EmbedConfigureOutput,
  EmbedContract,
  EmbedInitState,
  EmbedResetInput,
  EmbedResetOutput,
  EmbedSource,
  EmbedTestOutcome,
  EmbedTheme,
} from "./contract.ts";
export { EMBED_TEMPLATES } from "@jibe/starters/templates";
export type { EmbedTemplateId } from "@jibe/starters/templates";
export { failureCopy, isEmbedFailure, withFailure } from "./failures.ts";
export type { EmbedFailure, FailureCopy } from "./failures.ts";
export { connectJibeEmbedPort, createJibeEmbed } from "./sdk.ts";
export type {
  EmbedChrome,
  EmbedContractClient,
  EmbedFailureInfo,
  EmbedFileInput,
  EmbedSnapshot,
  EmbedView,
  JibeEmbedConsoleEntry,
  JibeEmbedDisplayOptions,
  JibeEmbedHandle,
  JibeEmbedOptions,
} from "./sdk.ts";
export { defineJibeEmbed, OBSERVED_ATTRIBUTES } from "./element.ts";
export type { JibeEmbedElement } from "./element.ts";
