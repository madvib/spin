// packages/embed/src/sdk_mount.ts — one iframe mount: ready handshake,
// port transfer, host-event listener, `init`. Post-ready failures keep the
// frame up; pre-ready failures remove it.
import { createORPCClient } from "@orpc/client";
import { RPCLink } from "@orpc/client/message-port";
import { embedContract, type EmbedTestOutcome } from "./contract.ts";
import type { ContractRouterClient } from "@orpc/contract";
import { failureOf, withFailure } from "./failures.ts";
import type {
  EmbedAssistantMessage,
  EmbedAssistantRequest,
  EmbedAssistantToolDef,
  EmbedMountSeed,
  EmbedSnapshot,
} from "./sdk_types.ts";
import type { JibeEmbedOptions } from "./sdk.ts";
import { applyIframeAllow, buildEmbedUrl } from "./sdk_url.ts";
import type { SlotMount } from "./sdk_types.ts";

export type EmbedContractClient = ContractRouterClient<typeof embedContract>;
export type { SlotMount };

// Guards `jibe-embed-tests` payloads: maps well-shaped outcomes, else null.
function testsOutcomeOf(payload: unknown): EmbedTestOutcome | null {
  if (typeof payload !== "object" || payload === null) return null;
  const passed = Reflect.get(payload, "passed");
  const failed = Reflect.get(payload, "failed");
  const rawFiles = Reflect.get(payload, "files");
  if (
    typeof passed !== "number" ||
    typeof failed !== "number" ||
    !Array.isArray(rawFiles)
  ) {
    return null;
  }
  const files: Array<EmbedTestOutcome["files"][number]> = [];
  for (const file of rawFiles) {
    if (typeof file !== "object" || file === null) return null;
    const filePath = Reflect.get(file, "file");
    const filePassed = Reflect.get(file, "passed");
    const fileFailed = Reflect.get(file, "failed");
    const rawCases = Reflect.get(file, "cases");
    if (
      typeof filePath !== "string" ||
      typeof filePassed !== "number" ||
      typeof fileFailed !== "number" ||
      !Array.isArray(rawCases)
    ) {
      return null;
    }
    const cases: Array<EmbedTestOutcome["files"][number]["cases"][number]> = [];
    for (const entry of rawCases) {
      if (typeof entry !== "object" || entry === null) return null;
      const suite = Reflect.get(entry, "suite");
      const name = Reflect.get(entry, "name");
      const casePassed = Reflect.get(entry, "passed");
      const durationMs = Reflect.get(entry, "durationMs");
      const error = Reflect.get(entry, "error");
      if (
        typeof suite !== "string" ||
        typeof name !== "string" ||
        typeof casePassed !== "boolean" ||
        typeof durationMs !== "number"
      ) {
        return null;
      }
      cases.push({
        suite,
        name,
        passed: casePassed,
        durationMs,
        ...(typeof error === "string" ? { error } : {}),
      });
    }
    files.push({
      file: filePath,
      passed: filePassed,
      failed: fileFailed,
      cases,
    });
  }
  return { passed, failed, files };
}

// Guards `jibe-embed-assistant` payloads; the reply posts back to the frame.
function assistantRequestOf(
  payload: unknown,
  workspaceId: string,
  iframe: HTMLIFrameElement,
  targetOrigin: string,
): EmbedAssistantRequest | null {
  if (typeof payload !== "object" || payload === null) return null;
  const rawThread = Reflect.get(payload, "thread");
  const rawTools = Reflect.get(payload, "tools");
  if (!Array.isArray(rawThread) || !Array.isArray(rawTools)) return null;
  const thread: Array<EmbedAssistantMessage> = [];
  for (const entry of rawThread) {
    if (typeof entry !== "object" || entry === null) return null;
    const role = Reflect.get(entry, "role");
    const text = Reflect.get(entry, "text");
    const toolName = Reflect.get(entry, "toolName");
    if (
      (role !== "user" && role !== "assistant" && role !== "tool") ||
      typeof text !== "string"
    ) {
      return null;
    }
    thread.push({
      role,
      text,
      ...(typeof toolName === "string" ? { toolName } : {}),
    });
  }
  const tools: Array<EmbedAssistantToolDef> = [];
  for (const entry of rawTools) {
    if (typeof entry !== "object" || entry === null) return null;
    const name = Reflect.get(entry, "name");
    const description = Reflect.get(entry, "description");
    const inputSchema = Reflect.get(entry, "inputSchema");
    if (
      typeof name !== "string" ||
      typeof description !== "string" ||
      typeof inputSchema !== "object" ||
      inputSchema === null
    ) {
      return null;
    }
    tools.push({
      name,
      description,
      inputSchema: inputSchema as Readonly<Record<string, unknown>>,
    });
  }
  return {
    workspaceId,
    thread,
    tools,
    reply: (text: string): void => {
      iframe.contentWindow?.postMessage(
        { kind: "jibe-assistant-reply", workspaceId, text },
        targetOrigin,
      );
    },
  };
}

export function connectJibeEmbedPort(
  port: Pick<MessagePort, "addEventListener" | "postMessage">,
): EmbedContractClient {
  try {
    (port as unknown as { start?: () => void }).start?.();
  } catch {
    /* a started port stays started */
  }
  const link = new RPCLink({
    port: port as MessagePort,
  });
  return createORPCClient(link) as EmbedContractClient;
}

export interface MountFrameDeps {
  readonly seed: EmbedMountSeed;
  readonly options: JibeEmbedOptions;
  readonly container: HTMLElement;
  readonly workspaceId: string;
  readonly snapshotSeed: EmbedSnapshot | null;
}

export async function mountEmbedFrame(
  deps: MountFrameDeps,
): Promise<SlotMount> {
  const { seed, options, container, workspaceId } = deps;
  const iframe = document.createElement("iframe");
  applyIframeAllow(iframe);
  iframe.src = buildEmbedUrl(seed.embedOrigin, seed.params);
  iframe.style.border = "0";
  iframe.style.width = "100%";
  iframe.style.height = "100%";
  container.appendChild(iframe);

  let channel: MessageChannel | null = null;
  let hostEventListener: ((event: MessageEvent) => void) | null = null;
  let readySettled = false;
  try {
    await new Promise<void>((resolve, reject) => {
      const onMessage = (event: MessageEvent): void => {
        if (event.source !== iframe.contentWindow) return;
        if (event.origin !== seed.targetOrigin) return;
        const data: unknown = event.data;
        if (typeof data !== "object" || data === null) return;
        if (Reflect.get(data, "workspaceId") !== workspaceId) return;
        if (Reflect.get(data, "kind") === "jibe-embed-ready") {
          clearTimeout(timer);
          window.removeEventListener("message", onMessage);
          resolve();
          return;
        }
        // A refusing host reports before ready (the isolation gate fires
        // during boot): reject with the host's kind now instead of sitting
        // out the 30s timer and misreporting `origin-unreachable`.
        if (
          Reflect.get(data, "kind") === "jibe-embed-status" &&
          Reflect.get(data, "status") === "error"
        ) {
          clearTimeout(timer);
          window.removeEventListener("message", onMessage);
          const message = Reflect.get(data, "message");
          reject(
            withFailure(
              new Error(
                typeof message === "string" && message !== ""
                  ? message
                  : "The embed host reported an error before it was ready.",
              ),
              failureOf(data) ?? "origin-unreachable",
            ),
          );
        }
      };
      const timer = setTimeout(() => {
        window.removeEventListener("message", onMessage);
        reject(
          withFailure(
            new Error("timed out waiting for jibe-embed-ready"),
            "origin-unreachable",
          ),
        );
      }, 30000);
      window.addEventListener("message", onMessage);
    });
    readySettled = true;

    channel = new MessageChannel();
    try {
      channel.port1.start();
    } catch {
      /* a started port stays started */
    }
    iframe.contentWindow?.postMessage(
      { kind: "jibe-embed-port" },
      seed.targetOrigin,
      [channel.port2],
    );
    const client = connectJibeEmbedPort(channel.port1);

    hostEventListener = (event: MessageEvent): void => {
      if (event.source !== iframe.contentWindow) return;
      if (event.origin !== seed.targetOrigin) return;
      const data: unknown = event.data;
      if (typeof data !== "object" || data === null) return;
      if (Reflect.get(data, "workspaceId") !== workspaceId) return;
      const kind = Reflect.get(data, "kind") ?? Reflect.get(data, "type");
      if (kind === "jibe-embed-remix") {
        const snapshot = Reflect.get(data, "snapshot") as EmbedSnapshot;
        options.onFork?.(snapshot);
        return;
      }
      if (kind === "jibe-embed-status") {
        if (Reflect.get(data, "status") === "error") {
          options.onError?.({
            kind: failureOf(data),
            message:
              typeof Reflect.get(data, "message") === "string"
                ? (Reflect.get(data, "message") as string)
                : "The embed host reported an error.",
          });
        }
        return;
      }
      if (kind === "jibe-embed-console") {
        const level = Reflect.get(data, "level");
        const args = Reflect.get(data, "args");
        const timestamp = Reflect.get(data, "timestamp");
        if (
          (level === "log" ||
            level === "info" ||
            level === "warn" ||
            level === "error") &&
          Array.isArray(args)
        ) {
          options.onConsole?.({
            level,
            args: args.map((item) => String(item)),
            timestamp: typeof timestamp === "number" ? timestamp : Date.now(),
          });
        }
      }
      if (kind === "jibe-embed-tests") {
        const outcome = testsOutcomeOf(Reflect.get(data, "outcome"));
        if (outcome !== null) options.onTestComplete?.(outcome);
      }
      if (kind === "jibe-embed-assistant") {
        const request = assistantRequestOf(
          Reflect.get(data, "request"),
          workspaceId,
          iframe,
          seed.targetOrigin,
        );
        if (request !== null) options.onAssistant?.(request);
      }
    };
    window.addEventListener("message", hostEventListener);

    const snapshotSeed = deps.snapshotSeed;
    const fileSource =
      snapshotSeed !== null
        ? { kind: "files" as const, files: { ...snapshotSeed.files } }
        : (seed.fromSource ?? {
            kind: "files" as const,
            files: seed.overlayFiles,
          });
    await client.init({
      ...(options.workspaceId === undefined
        ? {}
        : { workspaceId: options.workspaceId }),
      bundler: seed.bundler,
      ...(seed.activeFile === undefined ? {} : { activeFile: seed.activeFile }),
      view: seed.view,
      ...(snapshotSeed !== null || options.template === undefined
        ? {}
        : { template: options.template }),
      ...(options.visibleFiles === undefined
        ? {}
        : { visibleFiles: [...options.visibleFiles] }),
      ...(seed.overlayHidden.length === 0
        ? {}
        : { hiddenFiles: [...seed.overlayHidden] }),
      ...(seed.overlayReadOnly.length === 0
        ? {}
        : { readOnlyFiles: [...seed.overlayReadOnly] }),
      ...(options.externalResources === undefined
        ? {}
        : { externalResources: [...options.externalResources] }),
      ...(snapshotSeed !== null ||
      seed.fromSource === undefined ||
      Object.keys(seed.overlayFiles).length === 0
        ? {}
        : { files: seed.overlayFiles }),
      source: fileSource,
    });
    if (channel === null || hostEventListener === null) {
      throw new Error("embed mount lost its channel");
    }
    return { iframe, client, channel, listener: hostEventListener };
  } catch (error: unknown) {
    if (hostEventListener !== null) {
      window.removeEventListener("message", hostEventListener);
    }
    channel?.port1.close();
    // A post-ready failure leaves the frame up: the host renders the
    // failure copy into it (the failures suite proves this). A wake that
    // fails this way sweeps the remnant on its next retry (see `wakeLocked`).
    if (!readySettled) {
      iframe.remove();
    }
    options.onError?.({
      kind: failureOf(error),
      message: error instanceof Error ? error.message : String(error),
    });
    throw error;
  }
}
